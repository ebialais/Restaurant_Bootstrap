# Todolist partagée en temps réel

## Prérequis

Afin de pouvoir lancer le programme, il est nécessaire d'avoir NPM installé sur votre ordinateur.

## Lancement du programme

1. Ouvrez votre terminal à la racine du dossier et entrez les commandes suivantes dans l'ordre :
    1. sudo npm install
    2. npm start
2. Allez sur votre navigateur favori, et entrez l'adresse suivante dans la barre d'adresse : http://localhost:8080

## Fonctionnement de l'application

L'application est divisée en plusieurs parties :

* **app.js** : fichier Javascript exécuté coté serveur
* **views** : dossier contenant le contenu HTML et Javascript exécuté coté client (les fichiers sont au format *.ejs*)
* **public** : dossier contenant la feuille de style CSS ainsi que le framework css Semantic UI utilisé
* **package.json** : Fichier nécessaire pour l'installation des différents modules requis pour l'exécution du programme, comme vu dans la partie précédente.

### app.js

En sus des différents modules vus et utilisés dans le cadre de ce cours, j'y ai inclu un template engine (*ejs*). Celui-ci permet de créer du HTML à l'aide de Javascript.

J'ai également défini un chemin statique *./assets* qui permet à l'application d'accéder au dossier *./public* à l'aide du raccourci. Bien que peu utile dans cette application, j'ai pris l'habitude de l'inclure.

L'historique de la todolist est stocké dans l'array *items*. Bien entendu, ce tableau est recréé à chaque reset du serveur.

Le reste du code concerne la communication, à l'aide de socket.io, entre le serveur et le client.

### views

Le dossier *views* contient les 3 fichiers *.ejs* qui composent notre page.
Ils sont décomposés comme suit :

* **header.ejs** : Contient la partie head du fichir html lu par le navigateur, ainsi qu'un barre de navigation simple que j'ai pris l'habitude d'inclure en début de page.
* **index.ejs** : Fichier lu par le navigateur. Il importe lui-même les fichiers *header.ejs* et *footer.ejs*.
Le reste du fichier contient les grandes lignes du contenu HTML de la page, tels que le header et les différentes divs qui composent le squelette de la page.
* **footer.ejs** : Ce fichier, importé à la fin de *index.ejs*, contient trois parties : 
    1. Le chargement des scripts externes (*socket.io* coté client et *semantic UI*)
    2. Le script principal effectué coté client (qui pourrait être inclu dans un fichier *.js* lié à un *.html* par exemple).
    Le contenu de ce script est commenté à l'intérieur du fichier afin de facilité la compréhension.
    3. Les balises de fermeture du fichier html

### public

Le dossier public contient 2 parties : 

* le dossier *css* contenant un fichier *style.css* lu par le navigateur. Ce fichier contient deux petites modifications de mise en page.
* le dossier *semantic* contenant le framework css utilisé pour la mise en page de l'application.

### package.json

Contient les informations relatives à l'application telles que les dépendances et les scripts NPM utilisés.

## Auteur 

Maxime Broodcoorens

## Contact 

Vous pouvez me contacter par mail à l'adresse suivante *broodcoorens.maxime@gmail.com*.